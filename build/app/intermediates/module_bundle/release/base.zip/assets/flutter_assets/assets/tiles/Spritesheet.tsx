<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Spritesheet" tilewidth="32" tileheight="32" tilecount="11" columns="11">
 <image source="../images/Spritesheet.png" width="354" height="32"/>
</tileset>
